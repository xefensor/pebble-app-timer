'use strict';
// Generated from Timer and pinned pebble-activities sources; see bundled licenses.
(function(modules){var cache={};function load(id){if(cache[id])return cache[id].exports;var module={exports:{}};cache[id]=module;modules[id](module,module.exports,load);return module.exports;}load(0);})([
function(module,exports,require){
'use strict';

var activities = require(1);
var summary = require(6);
var timerUuid = '50e9ef12-a5ab-4369-a3b5-3447bfba5151';
function generatedTimerName(name) {
  if (typeof name !== 'string') return false;
  var match, seconds;
  if ((match = /^(\d+) h timer$/.exec(name))) seconds = Number(match[1]) * 3600;
  else if ((match = /^(\d+) min timer$/.exec(name))) seconds = Number(match[1]) * 60;
  else if ((match = /^(\d+):(\d{2}):(\d{2}) timer$/.exec(name))) {
    if (Number(match[2]) > 59 || Number(match[3]) > 59) return false;
    seconds = Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]);
  } else if ((match = /^(\d{2}):(\d{2}) timer$/.exec(name))) {
    if (Number(match[1]) > 59 || Number(match[2]) > 59) return false;
    seconds = Number(match[1]) * 60 + Number(match[2]);
  } else return false;
  if (!isFinite(seconds) || seconds < 5 || seconds > 86400) return false;
  function two(value) { return value < 10 ? '0' + value : String(value); }
  var canonical = seconds % 3600 === 0 ? seconds / 3600 + ' h timer' :
    seconds % 60 === 0 ? seconds / 60 + ' min timer' :
    seconds >= 3600 ? Math.floor(seconds / 3600) + ':' + two(Math.floor(seconds / 60) % 60) + ':' + two(seconds % 60) + ' timer' :
    two(Math.floor(seconds / 60)) + ':' + two(seconds % 60) + ' timer';
  return name === canonical;
}
var provider = activities.createProvider({
  storage: localStorage,
  pluginUuid: timerUuid,
  presentation: 'simple',
  appName: 'Timer',
  // Keep the previous card source readable for hosts which have not adopted
  // activity/live. Normal/compact display geometry belongs to each host.
  timerPresentation: 'compact'
});
var summaries = summary.defineSnapshotProvider({
  storage: localStorage,
  pluginUuid: timerUuid,
  displayName: 'Timer',
  icon: 'timer',
  readSnapshot: function () {
    // The native owner already persisted the snapshot through its receipt
    // protocol. A source read preserves those anchors and acknowledged results.
    return activities.readSnapshots({storage: localStorage, pluginUuid: timerUuid});
  },
  adapt: function (snapshot) {
    var adapted = summary.adapters.timerSnapshot(snapshot);
    // The native list generates duration labels, not custom instance names.
    // Keep the identity footer useful without repeating a configured duration.
    // Repeat duration is independent of totalDuration after edits/snoozes.
    if (adapted && generatedTimerName(adapted.record.name)) delete adapted.record.name;
    return adapted;
  }
});

Pebble.registerSourceHandler(function (request, respond) {
  if (request && request.category === 'activity' && request.item === summary.ITEM) {
    return summaries.handleSource(request, respond);
  }
  return provider.handleSource(request, respond);
});

// Appearance configuration shares the app UUID but no native timer bank/state.
// The current phone app can invoke this handler while Timer is closed.
if (typeof Pebble.registerConfigHandler === 'function') {
  var settings = require(9);
  Pebble.registerConfigHandler(function(message, respond) {
    settings.handle(localStorage, message, respond);
  });
}

},
function(module,exports,require){
'use strict';
module.exports = require(2);

},
function(module,exports,require){
'use strict';

var wire=require(3);
var view=require(4);
var activity=require(5);
var DEFAULT_KEY='pebble.activities.publisher.v1';
var MAX_RECORDS=8;
function record(snapshot,provider){
  var card=wire.normalize(snapshot,provider);
  if(!card){return null;}
  if(snapshot.totalDuration!==undefined){
    if(!wire.integer(snapshot.totalDuration,0,wire.MAX_EPOCH)){return null;}
    card.totalDuration=snapshot.totalDuration;
  }
  if(snapshot.showTerminal!==undefined){
    if(typeof snapshot.showTerminal!=='boolean'){return null;}
    card.showTerminal=snapshot.showTerminal;
  }
  return card;
}
function storageOf(options) {
  var storage=options.storage;
  if(!storage || typeof storage.getItem!=='function' || typeof storage.setItem!=='function') {throw new Error('STORAGE_UNAVAILABLE');}
  if(!wire.uuid(options.pluginUuid)) {throw new Error('INVALID_PROVIDER');}
  return storage;
}
function loadState(storage,key,provider) {
  try {
    var value=JSON.parse(storage.getItem(key));
    if(!value || value.schemaVersion!==1) {return {revision:0,slots:[]};}
    var revision=wire.integer(value.revision,1,wire.MAX_EPOCH)?value.revision:0;
    // Version 0.1.0/0.1.1 stored one card at this same key. Read it as slot 0;
    // opt-in collection writers migrate it on their next accepted snapshot.
    var source=Array.isArray(value.slots)?value.slots:[value.card];
    if(source.length>MAX_RECORDS) {return {revision:revision,slots:[]};}
    var slots=[],identities=Object.create(null);
    for(var i=0;i<source.length;i++) {
      if(source[i]===null || source[i]===undefined) {slots.push(null);continue;}
      var card=record(source[i],provider);
      if(!card || card.private || identities[card.id]) {return {revision:revision,slots:[]};}
      identities[card.id]=true;
      revision=Math.max(revision,card.revision);
      slots.push(card);
    }
    return {revision:revision,slots:slots};
  } catch(ignored) {return {revision:0,slots:[]};}
}
function createPublisher(options) {
  options=options||{};
  var storage=storageOf(options), key=options.key||DEFAULT_KEY;
  var maxRecords=options.maxRecords===undefined?1:options.maxRecords;
  if(!wire.integer(maxRecords,1,MAX_RECORDS)) {throw new Error('INVALID_RECORD_LIMIT');}
  function save(revision,slots) {
    // Keep the original envelope for default single-record publishers.
    var value=maxRecords===1?{schemaVersion:1,revision:revision,card:slots[0]||null}:
      {schemaVersion:1,revision:revision,slots:slots};
    try {
      storage.setItem(key,JSON.stringify(value));
      var read=loadState(storage,key,options.pluginUuid);
      if(read.revision!==revision || JSON.stringify(read.slots)!==JSON.stringify(slots)) {return false;}
      return true;
    } catch(ignored) {return false;}
  }
  function accept(snapshot) {
    if(!snapshot || snapshot.schemaVersion!==1) {return {ACTIVITY_ERROR:'INVALID_SNAPSHOT'};}
    var slot=snapshot.slot===undefined?0:snapshot.slot;
    if(!wire.integer(slot,0,maxRecords-1)) {return {ACTIVITY_ERROR:'INVALID_SLOT'};}
    var card=record(snapshot,options.pluginUuid);
    if(!card) {return {ACTIVITY_ERROR:'INVALID_SNAPSHOT'};}
    var saved=loadState(storage,key,options.pluginUuid),previous=saved.slots[slot];
    if(card.revision<saved.revision) {return {ACTIVITY_ERROR:'STALE_REVISION'};}
    // An accidental/default smaller writer must not silently discard another
    // slot. Reopen with the established limit to update or retract those slots.
    if(saved.slots.slice(maxRecords).some(function(record){return !!record;})) {
      return {ACTIVITY_ERROR:'RECORD_LIMIT_CONFLICT'};
    }
    var slots=saved.slots.slice(0,maxRecords);
    while(slots.length<maxRecords) {slots.push(null);}
    // A stable host-owned slot replaces its prior run atomically. It is not a
    // second public identity: source consumers still see the card's run ID.
    // This prevents an offline restart from leaving the predecessor running.
    for(var at=0;at<slots.length;at++) {
      if(at!==slot && slots[at] && slots[at].id===card.id) {return {ACTIVITY_ERROR:'SLOT_CONFLICT'};}
    }
    // Redact this slot's previous public contents and retain only the global
    // numeric floor. Never persist the private run identity or body. Other
    // public slots are independent and stay available.
    if(card.private) {
      slots[slot]=null;
      if(!save(card.revision,slots)) {return {ACTIVITY_ERROR:'STORAGE_FAILED'};}
      return {ACTIVITY_ERROR:'PRIVATE_PERSISTENCE_DISABLED'};
    }
    if(previous && previous.id===card.id && (previous.state==='completed'||previous.state==='cancelled') && card.state!=='completed' && card.state!=='cancelled'){return {ACTIVITY_ERROR:'TERMINAL_RUN'};}
    var serialized=JSON.stringify(card);
    if(card.revision===saved.revision && (!previous || previous.revision!==card.revision ||
        JSON.stringify(previous)!==serialized)) {return {ACTIVITY_ERROR:'REVISION_CONFLICT'};}
    slots[slot]=card;
    if(!save(card.revision,slots)) {return {ACTIVITY_ERROR:'STORAGE_FAILED'};}
    return {ACTIVITY_ACCEPTED_RUN:card.id,ACTIVITY_ACCEPTED_REVISION:card.revision};
  }
  function handleMessage(payload) {
    payload=payload && payload.payload ? payload.payload : payload;
    if(!payload || typeof payload!=='object' || payload.ACTIVITY_SCHEMA_VERSION===undefined) {return null;}
    var state=payload.ACTIVITY_STATE;
    if(state==='running') {state='active';}
    if(state==='finished') {state='completed';}
    var privacy=payload.ACTIVITY_PRIVATE;
    var validPrivacy=privacy===undefined || privacy===true || privacy===false || privacy===1 || privacy===0;
    var showTerminal=payload.ACTIVITY_SHOW_TERMINAL;
    var validTerminal=showTerminal===undefined || showTerminal===true || showTerminal===false || showTerminal===1 || showTerminal===0;
    var receipt=validPrivacy&&validTerminal?accept({schemaVersion:payload.ACTIVITY_SCHEMA_VERSION,id:payload.ACTIVITY_RUN,revision:payload.ACTIVITY_REVISION,
      state:state,kind:payload.ACTIVITY_KIND,clock:payload.ACTIVITY_CLOCK,name:payload.ACTIVITY_NAME,
      main:payload.ACTIVITY_MAIN,footer:payload.ACTIVITY_FOOTER,observedAt:payload.ACTIVITY_OBSERVED_AT,
      validUntil:payload.ACTIVITY_VALID_UNTIL,deadline:payload.ACTIVITY_DEADLINE,duration:payload.ACTIVITY_DURATION,
      clockAt:payload.ACTIVITY_CLOCK_AT,private:privacy===undefined ? options.private!==false : privacy===true || privacy===1,
      slot:payload.ACTIVITY_SLOT,totalDuration:payload.ACTIVITY_TOTAL_DURATION,
      showTerminal:showTerminal===undefined?undefined:showTerminal===true||showTerminal===1}):{ACTIVITY_ERROR:'INVALID_SNAPSHOT'};
    if(wire.integer(payload.ACTIVITY_PUBLISH_SESSION,1,wire.MAX_EPOCH)){receipt.ACTIVITY_PUBLISH_SESSION=payload.ACTIVITY_PUBLISH_SESSION;}
    return receipt;
  }
  return {accept:accept,handleMessage:handleMessage,onMessage:handleMessage,lastRevision:function(){return loadState(storage,key,options.pluginUuid).revision;}};
}
function base64(bytes) {
  var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';
  for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}
  return out;
}
function properties(card,request) {
  var p={schema_version:{numericValue:{value:1}},revision:{numericValue:{value:card.revision}},
    kind:{shortText:{text:card.kind}},state:{shortText:{text:card.state}},clock:{shortText:{text:card.clock}},
    name:{longText:{text:card.footer}},main:{longText:{text:card.main}},footer:{longText:{text:card.footer}},
    observed_at:{timestamp:{value:card.observedAt}},valid_until:{timestamp:{value:card.validUntil}},
    deadline:{timestamp:{value:card.deadline}},duration:{numericValue:{value:card.duration,unit:'s'}},
    clock_at:{timestamp:{value:card.clockAt}},private:{boolean:{value:card.private}},unconfirmed:{boolean:{value:true}}};
  if(card.value!==undefined) {p.value={numericValue:{value:card.value,unit:card.unit}};}
  if(card.image && request && request.iconPixelSize) {p.artwork={image:{width:card.image.width,height:card.image.height,palette:base64(card.image.palette),pixels:base64(card.image.pixels)}};}
  return p;
}
function createProvider(options) {
  options=options||{};
  if(options.presentation!==undefined&&options.presentation!=='simple'){throw new Error('INVALID_PRESENTATION');}
  if(options.timerPresentation!==undefined&&options.timerPresentation!=='detailed'&&options.timerPresentation!=='compact'){
    throw new Error('INVALID_TIMER_PRESENTATION');
  }
  var storage=storageOf(options),key=options.key||DEFAULT_KEY,now=options.now||Date.now;
  function source(request) {
    var nowMs=now(),slots=loadState(storage,key,options.pluginUuid).slots,instances=[];
    slots.forEach(function(card) {
      if(card && card.validUntil*1000>nowMs) {
        if(request&&request.item===activity.ITEM&&options.presentation==='simple'){
          var simple=activity.fromLegacy(card,{appName:options.appName});
          if(simple){simple.unconfirmed=true;var instance=activity.toSourceInstance(simple,request);if(instance){instances.push(instance);}}
        }else if(request&&request.item===view.ITEM){
          var projected=view.fromLegacy(card,{terminalResults:true,timerPresentation:options.timerPresentation});
          if(projected){projected.unconfirmed=true;var instance=view.toSourceInstance(projected,request);if(instance){instances.push(instance);}}
        }else{instances.push({instanceId:card.id,properties:properties(card,request)});}
      }
    });
    return {validUntilMs:Math.floor(nowMs+30000),instances:instances};
  }
  function handleSource(request,respond) {
    if(!request || request.category!==wire.CATEGORY || request.item!==wire.ITEM&&request.item!==view.ITEM&&
        !(request.item===activity.ITEM&&options.presentation==='simple')) {
      if(respond && typeof respond.error==='function') {respond.error('INVALID_REQUEST','Unsupported source');}
      return;
    }
    respond.data(source(request));
  }
  return {source:source,handleSource:handleSource};
}
function readSnapshots(options) {
  options=options||{};var storage=storageOf(options),key=options.key||DEFAULT_KEY;
  var raw=storage.getItem(key);if(raw===null||raw===undefined){return [];}
  var value;try{value=JSON.parse(raw);}catch(ignored){throw new Error('INVALID_SNAPSHOT_STORAGE');}
  if(!wire.object(value)||value.schemaVersion!==1){throw new Error('INVALID_SNAPSHOT_STORAGE');}
  var source=Array.isArray(value.slots)?value.slots:[value.card];
  if(source.length>MAX_RECORDS){throw new Error('INVALID_SNAPSHOT_STORAGE');}
  var seen=Object.create(null),result=[];
  source.forEach(function(input){
    if(input===null||input===undefined){return;}
    var card=record(input,options.pluginUuid);
    if(!card||card.private||seen[card.id]){throw new Error('INVALID_SNAPSHOT_STORAGE');}
    seen[card.id]=true;result.push(card);
  });
  return result;
}
module.exports={readSnapshots:readSnapshots,DEFAULT_KEY:DEFAULT_KEY,MAX_RECORDS:MAX_RECORDS,createPublisher:createPublisher,createProvider:createProvider};

},
function(module,exports,require){
'use strict';

var MAX = 4294967295;
var STATES = {active:1, paused:2, completed:3, cancelled:4};
var CLOCKS = {none:0, deadline:1, elapsed:2};
var LIMITS = {providers:32, instances:16, cards:2, main:192, footer:128, id:64, kind:24, unit:16, image:40, packet:2672};
function object(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }
function integer(v, min, max) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= min && v <= max; }
function uuid(v) { return typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v); }
function utf8(value) {
  var out=[];
  for (var i=0; i<value.length; i++) {
    var c=value.charCodeAt(i);
    if (c>=0xd800 && c<=0xdbff && i+1<value.length) {
      var next=value.charCodeAt(i+1);
      if (next>=0xdc00 && next<=0xdfff) { c=0x10000+((c-0xd800)<<10)+(next-0xdc00); i++; }
      else { c=0xfffd; }
    } else if (c>=0xd800 && c<=0xdfff) { c=0xfffd; }
    if (c<128) { out.push(c); }
    else if (c<2048) { out.push(192|(c>>6),128|(c&63)); }
    else if (c<65536) { out.push(224|(c>>12),128|((c>>6)&63),128|(c&63)); }
    else { out.push(240|(c>>18),128|((c>>12)&63),128|((c>>6)&63),128|(c&63)); }
  }
  return out;
}
function text(value, limit) {
  if (typeof value !== 'string') { return ''; }
  value=value.slice(0,4096).replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ').replace(/\s+/g,' ').trim();
  if (utf8(value).length<=limit) { return value; }
  var out='';
  for (var i=0; i<value.length; i++) {
    var c=value.charAt(i), code=value.charCodeAt(i);
    if (code>=0xd800 && code<=0xdbff && i+1<value.length) { c+=value.charAt(++i); }
    if (utf8(out+c).length>limit-3) { break; }
    out+=c;
  }
  return out+'\u2026';
}
function identity(v, limit) { return typeof v === 'string' && v.length>0 && !/[\x00-\x1f\x7f-\x9f]/.test(v) && utf8(v).length<=limit ? v : null; }
function bytes(v, max) {
  if (Array.isArray(v)) { return v.length<=max && v.every(function(n){return integer(n,0,255);}) ? v.slice() : null; }
  if (typeof v !== 'string' || v.length>Math.ceil(max/3)*4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(v)) { return null; }
  var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', out=[];
  for (var i=0;i<v.length;i+=4) {
    var a=alphabet.indexOf(v[i]), b=alphabet.indexOf(v[i+1]), c=v[i+2]==='='?0:alphabet.indexOf(v[i+2]), d=v[i+3]==='='?0:alphabet.indexOf(v[i+3]);
    if (v[i+2]==='=' && (b&15) || v[i+3]==='=' && v[i+2]!=='=' && (c&3)) { return null; }
    out.push((a<<2)|(b>>4));
    if(v[i+2]!=='=') {out.push(((b&15)<<4)|(c>>2));}
    if(v[i+3]!=='=') {out.push(((c&3)<<6)|d);}
  }
  return out.length<=max ? out : null;
}
function image(v) {
  if (!object(v) || !integer(v.width,1,40) || !integer(v.height,1,40)) { return null; }
  var palette=bytes(v.palette,16), pixels=bytes(v.pixels,800), stride=Math.ceil(v.width/2);
  if (!palette || !palette.length || !pixels || pixels.length!==stride*v.height) { return null; }
  for (var y=0;y<v.height;y++) {
    for (var x=0;x<v.width;x++) { var pair=pixels[y*stride+(x>>1)], n=x&1 ? pair&15 : pair>>4; if(n>=palette.length) {return null;} }
    if(v.width&1) { pixels[y*stride+stride-1]&=240; }
  }
  while(palette.length<16) {palette.push(0);}
  return {width:v.width,height:v.height,palette:palette,pixels:pixels};
}
function normalize(v, provider) {
  if (!object(v) || !uuid(provider || v.provider)) { return null; }
  var id=identity(v.id,LIMITS.id), kind=identity(typeof v.kind==='string'?v.kind.toLowerCase():v.kind,LIMITS.kind);
  var state=v.state==='running'?'active':v.state==='finished'?'completed':v.state;
  if(!id || !kind || !STATES[state] || !Object.prototype.hasOwnProperty.call(CLOCKS,v.clock) ||
      !integer(v.revision,1,MAX) || !integer(v.observedAt,1,MAX) || !integer(v.validUntil,v.observedAt,MAX)) { return null; }
  var result={provider:provider || v.provider,id:id,kind:kind,state:state,clock:v.clock,revision:v.revision,
    observedAt:v.observedAt,validUntil:v.validUntil,deadline:v.deadline===undefined?0:v.deadline,
    duration:v.duration===undefined?0:v.duration,clockAt:v.clockAt===undefined?0:v.clockAt,
    main:text(v.main,LIMITS.main),footer:text(v.footer===undefined?v.name:v.footer,LIMITS.footer),unit:text(v.unit,LIMITS.unit),private:v.private!==false||kind==='music'||kind==='notification'||kind==='notifications',unconfirmed:v.unconfirmed===true};
  if(result.private && result.unconfirmed) {return null;}
  if(!integer(result.deadline,0,MAX) || !integer(result.duration,0,MAX) || !integer(result.clockAt,0,MAX)) { return null; }
  if(state==='completed' || state==='cancelled') { result.clock='none';result.deadline=result.duration=result.clockAt=0; }
  if(result.clock==='none' && (result.deadline || result.duration || result.clockAt)) {return null;}
  if(result.clock==='deadline') {
    if(state==='active' && (!result.deadline || result.duration || result.clockAt)) {return null;}
    if(state==='paused' && (result.deadline || result.clockAt)) {return null;}
  }
  if(result.clock==='elapsed' && (result.deadline || state==='active' && !result.clockAt || state==='paused' && result.clockAt)) {return null;}
  if(result.clock==='none' && (state==='active'||state==='paused') && !result.main && (v.value===undefined||v.value===null)) {return null;}
  if(v.value!==undefined && v.value!==null) { if(typeof v.value!=='number'||!isFinite(v.value)) {return null;} result.value=v.value; }
  if(v.image!==undefined && v.image!==null) {result.image=image(v.image);if(!result.image) {return null;}}
  return result;
}
function put16(out, at, v) {out[at]=v&255;out[at+1]=(v>>>8)&255;}
function put32(out, at, v) {for(var i=0;i<4;i++){out[at+i]=Math.floor(v/Math.pow(256,i))&255;}}
function crc16(out) {var crc=65535;for(var i=0;i<out.length;i++){if(i===8||i===9){continue;}crc^=out[i]<<8;for(var n=0;n<8;n++){crc=((crc<<1)^(crc&32768?0x1021:0))&65535;}}return crc;}
function encode(cards, options) {
  options=options||{};
  if(!Array.isArray(cards)||cards.length>2||!integer(options.session,2,MAX)||!integer(options.revision,1,MAX)||!integer(options.sentAt,1,MAX)) {throw new Error('INVALID_SNAPSHOT');}
  var out=[65,67,84,49,1,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  put32(out,12,options.session);put32(out,16,options.revision);put32(out,20,options.sentAt);
  cards.forEach(function(raw){
    var card=normalize(raw);
    if(!card){throw new Error('INVALID_ACTIVITY');}
    var strings=[card.provider,card.id,card.kind,card.main,card.footer,card.unit].map(utf8), record=[];
    for(var i=0;i<48;i++){record.push(0);}
    record[0]=STATES[card.state];record[1]=CLOCKS[card.clock];record[2]=(card.private?1:0)|(card.image?2:0)|(card.value===undefined?0:4)|(card.unconfirmed?8:0);
    put32(record,4,card.revision);put32(record,8,card.observedAt);put32(record,12,card.validUntil);put32(record,16,card.deadline);put32(record,20,card.duration);put32(record,24,card.clockAt);
    if(card.value!==undefined){var b=new ArrayBuffer(8),view=new DataView(b);view.setFloat64(0,card.value,true);for(i=0;i<8;i++){record[28+i]=view.getUint8(i);}}
    strings.forEach(function(value,i){record[36+i]=value.length;});
    if(card.image){record[42]=card.image.width;record[43]=card.image.height;put16(record,44,card.image.pixels.length);}
    out=out.concat(record);strings.forEach(function(value){out=out.concat(value);});
    if(card.image){out=out.concat(card.image.palette,card.image.pixels);}
  });
  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
  put16(out,6,out.length);put16(out,8,crc16(out));return out;
}
function clockValue(card, now) {
  if(card.clock==='deadline'){return card.state==='paused'?card.duration:Math.max(0,card.deadline-Math.max(now,card.observedAt));}
  if(card.clock==='elapsed'){return Math.min(MAX,card.duration+(card.state==='active'?Math.max(0,now-card.clockAt):0));}
  return null;
}
function formatClock(seconds) {seconds=Math.max(0,Math.floor(seconds));var hours=Math.floor(seconds/3600),minutes=Math.floor(seconds/60)%60,s=seconds%60;return hours?hours+':'+('0'+minutes).slice(-2)+':'+('0'+s).slice(-2):('0'+minutes).slice(-2)+':'+('0'+s).slice(-2);}
module.exports={VERSION:1,CATEGORY:'activity',ITEM:'session',LIMITS:LIMITS,STATES:STATES,CLOCKS:CLOCKS,MAX_EPOCH:MAX,object:object,integer:integer,uuid:uuid,utf8:utf8,text:text,identity:identity,image:image,normalize:normalize,encode:encode,crc16:crc16,clockValue:clockValue,formatClock:formatClock};

},
function(module,exports,require){
'use strict';

// ACT2 is a bounded native view. Authoritative source revisions are checked by
// the consumer before projection; the frame sequence orders view changes.
var wire=require(3);
var MAX=wire.MAX_EPOCH;
var TYPES={text:1,value:2,clock:3};
var METERS={progress:1,level:2};
var LIMITS={cards:2,packet:2672,pool:320,label:64,text:192,caption:128};
var COMMON=['schema_version','kind','state','revision','name','caption','observed_at','valid_until','private','unconfirmed','show_terminal','artwork'];
var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
  name:['longText'],caption:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],show_terminal:['boolean'],artwork:['image','icon'],
  meter_kind:['shortText'],meter_source:['shortText'],meter_min:['numericValue'],meter_max:['numericValue']};
['main','support'].forEach(function(prefix){
  Object.keys({type:1,label:1,text:1,value:1,observed_at:1,valid_until:1,retain:1,estimated:1,clock:1,base:1,anchor:1,running:1}).forEach(function(suffix){
    SOURCE_PROPERTIES[prefix+'_'+suffix]=[suffix==='value'||suffix==='base'?'numericValue':suffix==='observed_at'||suffix==='valid_until'||suffix==='anchor'?'timestamp':suffix==='retain'||suffix==='estimated'||suffix==='running'?'boolean':suffix==='type'||suffix==='clock'?'shortText':'longText'];
  });
});
var PROPERTIES=Object.keys(SOURCE_PROPERTIES);
function bool(value){return value===undefined||typeof value==='boolean';}
function finite(value){return typeof value==='number'&&isFinite(value);}
function clean(value,limit){return wire.text(value,limit);}
function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
function scalar(properties,name,shape,field){return properties&&properties[name]&&properties[name][shape]?properties[name][shape][field||'value']:undefined;}
function string(properties,name){var value=scalar(properties,name,'longText','text');return value===undefined?scalar(properties,name,'shortText','text'):value;}
function datum(input,card,summaryProfile){
  if(!wire.object(input)||!Object.prototype.hasOwnProperty.call(TYPES,input.type)||!bool(input.retain)||!bool(input.estimated)||!bool(input.running)){return null;}
  var result={type:input.type,label:clean(input.label,LIMITS.label),text:'',
    observedAt:input.observedAt===undefined?card.observedAt:input.observedAt,
    validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
    retain:input.retain===true,estimated:input.estimated===true};
  if((!summaryProfile&&!result.label)||!wire.integer(result.observedAt,1,card.observedAt)||!wire.integer(result.validUntil,result.observedAt,card.validUntil)){return null;}
  if(input.type==='clock'){
    result.mode=input.mode;result.running=input.running===true;
    result.baseSeconds=input.baseSeconds===undefined?0:input.baseSeconds;
    result.anchorAt=input.anchorAt===undefined?0:input.anchorAt;
    if((result.mode!=='deadline'&&result.mode!=='elapsed')||!wire.integer(result.baseSeconds,0,MAX)||
        !wire.integer(result.anchorAt,0,result.observedAt)||(result.running?!result.anchorAt:result.anchorAt!==0)){return null;}
    if(input.text){return null;}
  } else {
    if(input.running===true||input.mode!==undefined||input.baseSeconds!==undefined&&input.baseSeconds!==0||input.anchorAt!==undefined&&input.anchorAt!==0){return null;}
    if(input.type==='value'&&input.value!==undefined){
      if(!finite(input.value)||input.unit!==undefined&&(typeof input.unit!=='string'||wire.utf8(input.unit).length>16)){return null;}
      result.value=input.value;result.unit=clean(input.unit,16);
      result.text=numericText(result.value,result.unit);
      if(input.text!==undefined&&input.text!==''&&clean(input.text,LIMITS.text)!==result.text){return null;}
    } else {result.text=clean(input.text,LIMITS.text);}
    if(!result.text||wire.utf8(result.text).length>LIMITS.text){return null;}
  }
  return result;
}
function poolFor(card){
  var bytes=[],known=Object.create(null);
  function add(value){
    value=value||'';
    if(Object.prototype.hasOwnProperty.call(known,value)){return known[value];}
    var encoded=wire.utf8(value),reference={offset:bytes.length,length:encoded.length};
    known[value]=reference;bytes=bytes.concat(encoded,[0]);return reference;
  }
  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)}};
  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
  return {bytes:bytes,refs:refs};
}
function normalize(input,provider,summaryProfile){
  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||!wire.identity(input.kind,24)||
      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
      !Object.prototype.hasOwnProperty.call(wire.STATES,input.state)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
  var kind=input.kind.toLowerCase(),card={provider:provider||input.provider,id:input.id,kind:kind,revision:input.revision,state:input.state,
    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,caption:clean(input.caption===undefined?input.name:input.caption,LIMITS.caption)};
  if(card.private&&card.unconfirmed){return null;}
  card.main=datum(input.main,card,summaryProfile);if(!card.main){return null;}
  card.support=input.support===undefined||input.support===null?null:datum(input.support,card,summaryProfile);
  if(input.support!==undefined&&input.support!==null&&!card.support){return null;}
  card.meter=null;
  if(input.meter!==undefined&&input.meter!==null){
    var m=input.meter,target=card[m.source];
    if(!wire.object(m)||!Object.prototype.hasOwnProperty.call(METERS,m.kind)||(m.source!=='main'&&m.source!=='support')||!target||target.type!=='value'){return null;}
    var fraction;
    if(m.min!==undefined||m.max!==undefined){
      if(!finite(m.min)||!finite(m.max)||m.max<=m.min||!finite(target.value)||target.value<m.min||target.value>m.max){return null;}
      fraction=(target.value-m.min)/(m.max-m.min);
    } else {fraction=m.fraction;}
    if(!finite(fraction)||fraction<0||fraction>1){return null;}
    card.meter={kind:m.kind,source:m.source,fraction:fraction};
    if(m.min!==undefined){card.meter.min=m.min;card.meter.max=m.max;}
  }
  if(input.image!==undefined&&input.image!==null){card.image=wire.image(input.image);if(!card.image){return null;}}
  if(!summaryProfile&&poolFor(card).bytes.length>LIMITS.pool){return null;}
  return card;
}
function fromLegacy(input,options){
  options=options||{};
  var legacy=wire.normalize(input);if(!legacy||!bool(input.showTerminal)||
      options.timerPresentation!==undefined&&options.timerPresentation!=='detailed'&&options.timerPresentation!=='compact'){return null;}
  var compactTimer=legacy.kind==='timer'&&options.timerPresentation==='compact';
  var main,terminal=legacy.state==='completed'||legacy.state==='cancelled';
  if(legacy.clock!=='none'){
    main={type:'clock',label:legacy.clock==='deadline'?'Left':'Elapsed',mode:legacy.clock,running:legacy.state==='active',
      baseSeconds:legacy.clock==='deadline'&&legacy.state==='active'?Math.max(0,legacy.deadline-legacy.observedAt):legacy.duration,
      anchorAt:legacy.state==='active'?(legacy.clock==='deadline'?legacy.observedAt:legacy.clockAt):0,retain:!legacy.private};
  } else {
    main={type:legacy.value===undefined?'text':'value',label:terminal?'State':legacy.value===undefined?'Text':'Value',
      text:legacy.main|| (legacy.value===undefined?(terminal?legacy.state:''):numericText(legacy.value,legacy.unit))};
  }
  var card={provider:legacy.provider,id:legacy.id,kind:legacy.kind,revision:legacy.revision,state:legacy.state,
    observedAt:legacy.observedAt,validUntil:legacy.validUntil,private:legacy.private,unconfirmed:legacy.unconfirmed,
    caption:legacy.footer,main:main,image:legacy.image};
  if(!compactTimer&&legacy.kind==='timer'&&legacy.clock==='deadline'&&wire.integer(input.totalDuration,0,MAX)){
    card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:legacy.state==='active',
      baseSeconds:Math.max(0,input.totalDuration-main.baseSeconds),anchorAt:legacy.state==='active'?legacy.observedAt:0,retain:!legacy.private};
  }
  if(options.terminalResults&&input.showTerminal!==false&&legacy.kind==='timer'&&legacy.state==='completed'){
    card.showTerminal=true;card.main={type:'text',label:'State',text:'Finished',retain:!legacy.private};
    if(!compactTimer&&wire.integer(input.totalDuration,0,MAX)){card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:false,baseSeconds:input.totalDuration,anchorAt:0,retain:!legacy.private};}
  }
  if(compactTimer&&legacy.clock==='deadline'&&card.caption){
    // One explicit identity caption fits both fields, so a host can deduplicate
    // by exact equality without guessing which clock labels are expendable.
    card.caption=clean(card.caption,LIMITS.label);card.main.label=card.caption;
  }
  // Legacy sources had separate maximum main/caption buffers. Fit the optional
  // caption into the shared pool; never trim a structured clock or value unit.
  var result=normalize(card);
  for(var limit=LIMITS.caption-1;!result&&limit>=0;limit--){card.caption=clean(legacy.footer,limit);result=normalize(card);}
  return result;
}
function put16(bytes,offset,value){bytes[offset]=value&255;bytes[offset+1]=(value>>>8)&255;}
function put32(bytes,offset,value){for(var i=0;i<4;i++){bytes[offset+i]=Math.floor(value/Math.pow(256,i))&255;}}
function writeDatum(header,offset,item,refs){
  if(!item){return;}
  header[offset]=TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);
  put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);
  put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
}
function encode(cards,options){
  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
  var out=[65,67,84,50,2,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
  cards.forEach(function(raw){
    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
    var pool=poolFor(card),id=wire.utf8(card.id),header=[];
    for(var i=0;i<88;i++){header.push(0);}
    header[2]=wire.STATES[card.state];header[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
    put32(header,4,card.revision);put32(header,8,card.observedAt);put32(header,12,card.validUntil);
    header[16]=id.length;header[17]=card.image?card.image.width:0;header[18]=card.image?card.image.height:0;
    header[19]=card.meter?METERS[card.meter.kind]:0;put16(header,20,card.image?card.image.pixels.length:0);put16(header,22,pool.bytes.length);
    put16(header,24,pool.refs.caption.offset);put16(header,26,pool.refs.caption.length);
    put16(header,28,card.meter?Math.round(card.meter.fraction*65535):0);header[30]=card.meter&&card.meter.source==='support'?1:0;
    writeDatum(header,32,card.main,pool.refs.main);writeDatum(header,60,card.support,pool.refs.support);
    var record=header.concat(wire.utf8(card.provider),id,pool.bytes);
    if(card.image){record=record.concat(card.image.palette,card.image.pixels);}
    put16(record,0,record.length);out=out.concat(record);
  });
  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
  put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
}
function readDatum(properties,prefix){
  var type=string(properties,prefix+'_type');if(type===undefined){return null;}
  var number=properties[prefix+'_value']&&properties[prefix+'_value'].numericValue;
  var body=string(properties,prefix+'_text');
  if(number&&(type!=='value'||body!==undefined&&body!=='')){return false;}
  return {type:type,label:string(properties,prefix+'_label'),text:body,
    value:number&&number.value,unit:number&&number.unit,observedAt:scalar(properties,prefix+'_observed_at','timestamp'),
    validUntil:scalar(properties,prefix+'_valid_until','timestamp'),retain:scalar(properties,prefix+'_retain','boolean'),estimated:scalar(properties,prefix+'_estimated','boolean'),
    mode:string(properties,prefix+'_clock'),running:scalar(properties,prefix+'_running','boolean'),
    baseSeconds:scalar(properties,prefix+'_base','numericValue'),anchorAt:scalar(properties,prefix+'_anchor','timestamp')};
}
function sourceCard(instance,provider){
  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==2){return null;}
  var main=readDatum(p,'main'),support=readDatum(p,'support');if(!main||support===false){return null;}
  var meterKind=string(p,'meter_kind'),meter=meterKind&&meterKind!=='none'?{kind:meterKind,source:string(p,'meter_source'),min:scalar(p,'meter_min','numericValue'),max:scalar(p,'meter_max','numericValue')}:null;
  return normalize({provider:provider,id:instance.instanceId,kind:string(p,'kind'),revision:scalar(p,'revision','numericValue'),state:string(p,'state'),
    observedAt:scalar(p,'observed_at','timestamp'),validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),
    unconfirmed:scalar(p,'unconfirmed','boolean'),showTerminal:scalar(p,'show_terminal','boolean'),caption:string(p,'caption')===undefined?string(p,'name'):string(p,'caption'),
    main:main,support:support,meter:meter,image:p.artwork&&(p.artwork.image||p.artwork.icon)});
}
function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
function toSourceInstance(input,request){
  var card=normalize(input);if(!card){return null;}
  var p={schema_version:{numericValue:{value:2}},revision:{numericValue:{value:card.revision}},kind:{shortText:{text:card.kind}},state:{shortText:{text:card.state}},
    name:{longText:{text:card.caption}},caption:{longText:{text:card.caption}},observed_at:{timestamp:{value:card.observedAt}},valid_until:{timestamp:{value:card.validUntil}},
    private:{boolean:{value:card.private}},unconfirmed:{boolean:{value:card.unconfirmed}},show_terminal:{boolean:{value:card.showTerminal}}};
  ['main','support'].forEach(function(prefix){var d=card[prefix];if(!d){return;}
    p[prefix+'_type']={shortText:{text:d.type}};p[prefix+'_label']={longText:{text:d.label}};
    p[prefix+'_observed_at']={timestamp:{value:d.observedAt}};p[prefix+'_valid_until']={timestamp:{value:d.validUntil}};
    p[prefix+'_retain']={boolean:{value:d.retain}};p[prefix+'_estimated']={boolean:{value:d.estimated}};
    if(d.type==='clock'){p[prefix+'_clock']={shortText:{text:d.mode}};p[prefix+'_base']={numericValue:{value:d.baseSeconds,unit:'s'}};p[prefix+'_anchor']={timestamp:{value:d.anchorAt}};p[prefix+'_running']={boolean:{value:d.running}};}
    else if(d.type==='value'&&finite(d.value)){p[prefix+'_value']={numericValue:{value:d.value,unit:d.unit}};}
    else{p[prefix+'_text']={longText:{text:d.text}};}
  });
  if(card.meter){if(!finite(card.meter.min)||!finite(card.meter.max)){return null;}p.meter_kind={shortText:{text:card.meter.kind}};p.meter_source={shortText:{text:card.meter.source}};p.meter_min={numericValue:{value:card.meter.min}};p.meter_max={numericValue:{value:card.meter.max}};}
  if(card.image&&request&&request.iconPixelSize){p.artwork={image:{width:card.image.width,height:card.image.height,palette:base64(card.image.palette),pixels:base64(card.image.pixels)}};}
  return {instanceId:card.id,properties:p};
}
module.exports={VERSION:2,CATEGORY:'activity',ITEM:'card',TYPES:TYPES,METERS:METERS,LIMITS:LIMITS,PROPERTIES:PROPERTIES,SOURCE_PROPERTIES:SOURCE_PROPERTIES,
  normalize:normalize,createCard:normalize,encode:encode,fromLegacy:fromLegacy,sourceCard:sourceCard,toSourceInstance:toSourceInstance,poolFor:poolFor,numericText:numericText};

},
function(module,exports,require){
'use strict';

// Public notification-style activities. The ACT2 card is an internal transport
// adapter; plugins never arrange slots, mandatory labels, meters or layouts.
var wire=require(3),view=require(4),MAX=wire.MAX_EPOCH;
var LIMITS={text:192,label:64,appName:32,descriptor:512};
var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
  app_name:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],
  unconfirmed:['boolean'],show_terminal:['boolean'],content:['longText'],detail:['longText'],artwork:['image','icon']};
var FIELDS=['provider','id','kind','state','revision','appName','observedAt','validUntil','private','unconfirmed','showTerminal','content','detail','image'];
var DATUM_FIELDS=['label','observedAt','validUntil','estimated'];
function own(value,key){return Object.prototype.hasOwnProperty.call(value,key);}
function known(value,keys){return wire.object(value)&&Object.keys(value).every(function(key){return keys.indexOf(key)>=0;});}
function bool(value){return value===undefined||typeof value==='boolean';}
function finite(value){return typeof value==='number'&&isFinite(value);}
function string(value,limit){return typeof value==='string'&&value.length<=limit&&wire.utf8(value).length<=limit?wire.text(value,limit):null;}
function datum(input,card){
  if(typeof input==='string'){input={text:input};}
  if(!wire.object(input)){return null;}
  var keys=DATUM_FIELDS.concat(own(input,'text')?['text']:own(input,'value')?['value','unit']:['clock','deadline','seconds','since']);
  if(!known(input,keys)||!bool(input.estimated)){return null;}
  var out={},label=input.label===undefined?'':string(input.label,LIMITS.label);
  if(label===null){return null;}if(label){out.label=label;}
  if(input.observedAt!==undefined){out.observedAt=input.observedAt;}
  if(input.validUntil!==undefined){out.validUntil=input.validUntil;}
  if(input.estimated!==undefined){out.estimated=input.estimated;}
  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
  var expiry=input.validUntil===undefined?card.validUntil:input.validUntil;
  if(!wire.integer(observed,1,card.observedAt)||!wire.integer(expiry,observed,card.validUntil)){return null;}
  if(own(input,'text')){
    out.text=string(input.text,LIMITS.text);if(!out.text){return null;}
  }else if(own(input,'value')){
    if(finite(input.value)){out.value=input.value;}
    else if(typeof input.value==='string'&&input.unit===undefined){out.value=string(input.value,LIMITS.text);if(!out.value){return null;}}
    else{return null;}
    if(input.unit!==undefined){out.unit=string(input.unit,16);if(out.unit===null){return null;}}
    if(wire.utf8(typeof out.value==='string'?out.value:view.numericText(out.value,out.unit)).length>LIMITS.text){return null;}
  }else{
    out.clock=input.clock;
    if(out.clock==='countdown'){
      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}out.deadline=input.deadline;}
      else{if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
    }else if(out.clock==='elapsed'){
      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
      if(input.since!==undefined){if(!wire.integer(input.since,1,observed)){return null;}out.since=input.since;}
      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
    }else{return null;}
  }
  return wire.utf8(JSON.stringify(out)).length<=LIMITS.descriptor?out:null;
}
function normalize(input,provider){
  if(!known(input,FIELDS)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||
      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||
      !wire.integer(input.validUntil,input.observedAt,MAX)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
  var kind=input.kind===undefined?'activity':wire.identity(input.kind,24),state=input.state===undefined?'active':input.state;
  if(!kind||!own(wire.STATES,state)){return null;}kind=kind.toLowerCase();
  var app=input.appName===undefined?'':string(input.appName,LIMITS.appName);if(app===null){return null;}
  var result={provider:provider||input.provider,id:input.id,kind:kind,state:state,revision:input.revision,
    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,appName:app};
  if(result.private&&result.unconfirmed){return null;}
  result.content=datum(input.content,result);if(!result.content){return null;}
  result.detail=input.detail===undefined||input.detail===null?null:datum(input.detail,result);
  if(input.detail!==undefined&&input.detail!==null&&!result.detail){return null;}
  if(input.image!==undefined&&input.image!==null){result.image=wire.image(input.image);if(!result.image){return null;}}
  return result;
}
function compiledDatum(input,card){
  var label=input.label||card.appName||'Activity';
  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
  var out={label:label,observedAt:observed,validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
    estimated:input.estimated===true,retain:!card.private};
  if(input.text!==undefined){out.type='text';out.text=input.text;}
  else if(input.value!==undefined){out.type='value';if(typeof input.value==='string'){out.text=input.value;}else{out.value=input.value;out.unit=input.unit||'';}}
  else{
    out.type='clock';out.mode=input.clock==='countdown'?'deadline':'elapsed';
    out.running=input.deadline!==undefined||input.since!==undefined;
    out.anchorAt=out.running?(input.since===undefined?observed:input.since):0;
    out.baseSeconds=input.deadline===undefined?input.seconds||0:Math.max(0,input.deadline-observed);
  }
  return out;
}
function toView(input,provider){
  var record=normalize(input,provider);if(!record){return null;}
  var projection={provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
    observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,unconfirmed:record.unconfirmed,
    showTerminal:record.showTerminal,caption:record.appName||'Activity',main:compiledDatum(record.content,record),
    support:record.detail?compiledDatum(record.detail,record):null,image:record.image};
  var card=view.normalize(projection);
  // A bounded native host can omit optional detail, never an essential value,
  // unit or clock. This does not modify the authoritative source/fingerprint.
  if(!card&&projection.support){projection.support=null;card=view.normalize(projection);}
  if(card){card.sourceFormat=3;if(record.appName){card.providerName=record.appName;}}
  return card;
}
function scalar(p,name,shape,field){return p&&p[name]&&p[name][shape]?p[name][shape][field||'value']:undefined;}
function parseDescriptor(p,name,optional){
  if(!p||p[name]===undefined){return optional?null:undefined;}
  var raw=scalar(p,name,'longText','text');
  if(typeof raw!=='string'||raw.length>LIMITS.descriptor||wire.utf8(raw).length>LIMITS.descriptor){return undefined;}
  try{var value=JSON.parse(raw);return wire.object(value)||typeof value==='string'?value:undefined;}catch(ignored){return undefined;}
}
function sourceCard(instance,provider){
  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==3){return null;}
  var malformed=Object.keys(SOURCE_PROPERTIES).some(function(name){
    if(p[name]===undefined||name==='artwork'){return false;}
    var shape=SOURCE_PROPERTIES[name][0],field=shape==='shortText'||shape==='longText'?'text':'value';
    return !wire.object(p[name])||!wire.object(p[name][shape])||scalar(p,name,shape,field)===undefined;
  });
  if(malformed||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
  var content=parseDescriptor(p,'content',false),detail=parseDescriptor(p,'detail',true);
  if(content===undefined||detail===undefined){return null;}
  return normalize({provider:provider,id:instance.instanceId,kind:scalar(p,'kind','shortText','text'),state:scalar(p,'state','shortText','text'),
    revision:scalar(p,'revision','numericValue'),appName:scalar(p,'app_name','longText','text'),observedAt:scalar(p,'observed_at','timestamp'),
    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
    showTerminal:scalar(p,'show_terminal','boolean'),content:content,detail:detail,image:p.artwork&&(p.artwork.image||p.artwork.icon)},provider);
}
function toSourceInstance(input,request){
  var record=normalize(input);if(!record){return null;}
  var p={schema_version:{numericValue:{value:3}},kind:{shortText:{text:record.kind}},state:{shortText:{text:record.state}},
    revision:{numericValue:{value:record.revision}},app_name:{longText:{text:record.appName}},observed_at:{timestamp:{value:record.observedAt}},
    valid_until:{timestamp:{value:record.validUntil}},private:{boolean:{value:record.private}},unconfirmed:{boolean:{value:record.unconfirmed}},
    show_terminal:{boolean:{value:record.showTerminal}},content:{longText:{text:JSON.stringify(record.content)}}};
  if(record.detail){p.detail={longText:{text:JSON.stringify(record.detail)}};}
  if(record.image&&request&&request.iconPixelSize){
    var internal=view.toSourceInstance(toView(record),request);if(!internal){return null;}p.artwork=internal.properties.artwork;
  }
  return {instanceId:record.id,properties:p};
}
function fromLegacy(input,options){
  options=options||{};var record=wire.normalize(input);if(!record){return null;}
  var content;
  if(record.clock==='deadline'){content={clock:'countdown'};content[record.state==='active'?'deadline':'seconds']=record.state==='active'?record.deadline:record.duration;}
  else if(record.clock==='elapsed'){content={clock:'elapsed',seconds:record.duration};if(record.state==='active'){content.since=record.clockAt;}}
  else if(record.kind==='timer'&&(record.state==='completed'||record.state==='cancelled')){content=record.state==='completed'?'Finished':'Cancelled';}
  else{content=record.value===undefined?record.main:{value:record.value,unit:record.unit};}
  return normalize({provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
    appName:options.appName||'',observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,
    unconfirmed:record.unconfirmed,showTerminal:input.showTerminal===true,content:content,image:record.image});
}
function helper(value,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(value).forEach(function(k){result[k]=value[k];});return result;}
function value(number,unit,options){var out={value:number};if(unit!==undefined){out.unit=unit;}return helper(out,options);}
function countdown(options){return helper({clock:'countdown'},options);}
function elapsed(options){return helper({clock:'elapsed'},options);}
function createProvider(options){
  options=options||{};if(!wire.uuid(options.pluginUuid)||typeof options.getActivities!=='function'){throw new Error('INVALID_PROVIDER');}
  var now=options.now||Date.now;
  function source(request){
    var input=options.getActivities(),instances=[];if(!Array.isArray(input)||input.length>wire.LIMITS.instances){throw new Error('INVALID_ACTIVITIES');}
    var time=now(),ids=Object.create(null);
    input.forEach(function(raw){
      var copy={};if(!wire.object(raw)){throw new Error('INVALID_ACTIVITY');}Object.keys(raw).forEach(function(k){copy[k]=raw[k];});
      if(copy.appName===undefined){copy.appName=options.appName;}
      var record=normalize(copy,options.pluginUuid);if(!record||ids[record.id]){throw new Error('INVALID_ACTIVITY');}ids[record.id]=true;
      if(record.validUntil*1000>time){var instance=toSourceInstance(record,request);if(!instance){throw new Error('INVALID_ACTIVITY');}instances.push(instance);}
    });
    return {validUntilMs:Math.min(MAX*1000,Math.floor(time+30000)),instances:instances};
  }
  function handleSource(request,respond){
    if(!request||request.category!=='activity'||request.item!=='live'){if(respond&&typeof respond.error==='function'){respond.error('INVALID_REQUEST','Unsupported source');}return;}
    try{respond.data(source(request));}catch(ignored){if(respond&&typeof respond.error==='function'){respond.error('INVALID_DATA','Invalid activity snapshot');}}
  }
  return {source:source,handleSource:handleSource};
}
module.exports={VERSION:3,CATEGORY:'activity',ITEM:'live',LIMITS:LIMITS,SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),
  normalize:normalize,toView:toView,sourceCard:sourceCard,toSourceInstance:toSourceInstance,fromLegacy:fromLegacy,
  value:value,countdown:countdown,elapsed:elapsed,createProvider:createProvider};

},
function(module,exports,require){
'use strict';
module.exports = require(7);

},
function(module,exports,require){
'use strict';

// Schema 4 is semantic source content. Layout and source observation are never
// supplied by fresh-read authors; imported owners use the separate snapshot path.
var wire=require(3),MAX=wire.MAX_EPOCH;
var ICONS=['activity','timer','stopwatch','media','message','call','navigation','workout','recording','download','delivery'];
var DIRECTIONS=['turn-left','turn-right','straight','u-turn'];
var STATES=['active','paused','completed','cancelled'];
var PLAYBACK=['playing','paused','buffering','stopped','unknown'];
var META_KEY='pebble.activities.summary.metadata.v1';
var LIMITS={records:16,descriptor:1024,text:192,label:32,name:64,value:64,unit:16,actions:1536,entity:256,openApp:96};
var SOURCE_PROPERTIES={schema_version:['numericValue'],publisher_incarnation:['longText'],publisher_mode:['shortText'],snapshot_sequence:['numericValue'],activity_count:['numericValue'],
  revision:['numericValue'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],content:['longText'],
  app_name:['longText'],icon:['image','icon'],artwork:['image','icon'],entity_ref:['longText'],actions:['longText'],open_app:['longText']};
var SHARED=['id','type','name','icon','visibleUntil','entityRef','actions','openApp'];
function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
function known(v,keys){return wire.object(v)&&Object.keys(v).every(function(k){return keys.indexOf(k)>=0;});}
function finite(v){return typeof v==='number'&&isFinite(v);}
function text(v,max){
  if(typeof v!=='string'||/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/.test(v)){return null;}
  var t=v.trim();
  if(!t||wire.utf8(t).length>max||/[\ud800-\udfff]/.test(t.replace(/[\ud800-\udbff][\udc00-\udfff]/g,''))){return null;}
  return t;
}
function bounded(v,max){try{return wire.utf8(JSON.stringify(v)).length<=max;}catch(ignored){return false;}}
function jsonValue(v,depth){
  if(v===null||typeof v==='string'||typeof v==='boolean'){return true;}
  if(typeof v==='number'){return finite(v);}
  if(depth<=0||typeof v!=='object'){return false;}
  if(Array.isArray(v)){return v.every(function(x){return jsonValue(x,depth-1);});}
  if(!wire.object(v)||Object.getPrototypeOf(v)!==Object.prototype&&Object.getPrototypeOf(v)!==null){return false;}
  return Object.keys(v).every(function(k){return jsonValue(v[k],depth-1);});
}
function extension(input,name){
  if(name==='openApp'){
    return known(input,['watchAppUuid'])&&wire.uuid(input.watchAppUuid)&&!/^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(input.watchAppUuid)?{watchAppUuid:input.watchAppUuid}:null;
  }
  if(name==='entityRef'){
    if(!known(input,['category','item','instanceId'])){return null;}
    var out={};
    if(!['category','item','instanceId'].every(function(k){out[k]=text(input[k],64);return !!out[k];})){return null;}
    return bounded(out,LIMITS.entity)?out:null;
  }
  if(!Array.isArray(input)||input.length>3){return null;}
  var ids=Object.create(null),result=[];
  for(var i=0;i<input.length;i++){
    var a=input[i];if(!known(a,['id','label','action','args','semantic'])){return null;}
    var action={id:text(a.id,32),label:text(a.label,32),action:text(a.action,64),args:a.args===undefined?{}:a.args};
    if(!action.id||!action.label||!action.action||ids[action.id]||!wire.object(action.args)||!jsonValue(action.args,4)||!bounded(action.args,256)){return null;}
    ids[action.id]=true;
    if(a.semantic!==undefined){if(['play','pause','resume','stop','next','previous','cancel','acknowledge'].indexOf(a.semantic)<0){return null;}action.semantic=a.semantic;}
    result.push(action);
  }
  return bounded(result,LIMITS.actions)?result:null;
}
function datum(input,observedAt){
  if(!wire.object(input)){return null;}
  var d={type:input.type},keys=['type','label'];
  if(input.type==='text'){
    keys.push('text');d.text=text(input.text,LIMITS.text);if(!d.text){return null;}
  }else if(input.type==='value'){
    keys=keys.concat(['value','unit','range','symbol']);
    d.value=finite(input.value)?input.value:text(input.value,LIMITS.value);if(d.value===null){return null;}
    if(input.unit!==undefined){d.unit=text(input.unit,LIMITS.unit);if(!d.unit){return null;}}
    if(input.range!==undefined){
      var r=input.range,min=r&&r.min===undefined?0:r&&r.min;
      if(!known(r,['min','max'])||!finite(d.value)||!finite(min)||!finite(r.max)||r.max<=min||d.value<min||d.value>r.max){return null;}
      d.range={min:min,max:r.max};
    }
    if(input.symbol!==undefined){if(DIRECTIONS.indexOf(input.symbol)<0){return null;}d.symbol=input.symbol;}
  }else if(input.type==='clock'){
    keys=keys.concat(['mode','deadline','since','seconds']);d.mode=input.mode;
    if(d.mode==='countdown'){
      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}d.deadline=input.deadline;}
      else{if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
    }else if(d.mode==='elapsed'){
      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
      if(input.since!==undefined){if(!wire.integer(input.since,1,observedAt||MAX)){return null;}d.since=input.since;}
      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
    }else{return null;}
  }else{return null;}
  if(!known(input,keys)){return null;}
  if(input.label!==undefined){d.label=text(input.label,LIMITS.label);if(!d.label){return null;}}
  return d;
}
function descriptor(record){
  var out={};Object.keys(record).forEach(function(k){
    if(k==='artwork'||k==='entityRef'||k==='actions'||k==='openApp'||k==='icon'&&typeof record.icon!=='string'){return;}out[k]=record[k];
  });return out;
}
function normalize(input,observedAt){
  var keys=SHARED.concat(input&&input.type==='media'?['title','artist','artwork','itemId','playback']:['headline','detail','summary','state','result']);
  if(!known(input,keys)||!text(input.id,64)||input.id[0]==='@'||input.id!==input.id.trim()){return null;}
  var out={id:input.id,type:input.type};
  if(input.name!==undefined){out.name=text(input.name,LIMITS.name);if(!out.name){return null;}}
  if(input.icon!==undefined){
    out.icon=typeof input.icon==='string'?(ICONS.indexOf(input.icon)>=0?input.icon:null):wire.image(input.icon);if(!out.icon){return null;}
  }
  if(input.visibleUntil!==undefined){if(!wire.integer(input.visibleUntil,1,MAX)){return null;}out.visibleUntil=input.visibleUntil;}
  ['entityRef','actions','openApp'].forEach(function(k){if(input[k]!==undefined){out[k]=extension(input[k],k);}});
  if(['entityRef','actions','openApp'].some(function(k){return own(out,k)&&out[k]===null;})){return null;}
  if(input.type==='standard'){
    out.headline=datum(input.headline,observedAt);if(!out.headline){return null;}
    if(input.detail!==undefined){out.detail=datum(input.detail,observedAt);if(!out.detail){return null;}}
    out.summary=input.summary===undefined?'headline':input.summary;
    out.state=input.state===undefined?'active':input.state;out.result=input.result===undefined?false:input.result;
    if(['headline','detail'].indexOf(out.summary)<0||out.summary==='detail'&&!out.detail||STATES.indexOf(out.state)<0||typeof out.result!=='boolean'||out.result&&out.state!=='completed'&&out.state!=='cancelled'){return null;}
  }else if(input.type==='media'){
    out.title=text(input.title,LIMITS.text);if(!out.title){return null;}
    if(input.artist!==undefined){out.artist=text(input.artist,LIMITS.text);if(!out.artist){return null;}}
    if(input.itemId!==undefined){out.itemId=text(input.itemId,64);if(!out.itemId){return null;}}
    out.playback=input.playback===undefined?'unknown':input.playback;if(PLAYBACK.indexOf(out.playback)<0){return null;}
    if(input.artwork!==undefined){out.artwork=wire.image(input.artwork);if(!out.artwork){return null;}}
  }else{return null;}
  return bounded(descriptor(out),LIMITS.descriptor)?out:null;
}
function sourceRecord(input,provider){
  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.integer(input.revision,1,MAX)||
    !wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
    input.private!==undefined&&typeof input.private!=='boolean'||input.unconfirmed!==undefined&&typeof input.unconfirmed!=='boolean'){return null;}
  var record=normalize(input.record,input.observedAt);if(!record){return null;}
  var out={provider:provider||input.provider,record:record,id:record.id,type:record.type,revision:input.revision,observedAt:input.observedAt,
    validUntil:Math.min(input.validUntil,record.visibleUntil===undefined?MAX:record.visibleUntil),private:record.type==='media'||input.private!==false,
    unconfirmed:input.unconfirmed===true,displayName:text(input.displayName,64)||''};
  if(out.validUntil<out.observedAt||out.private&&out.unconfirmed){return null;}
  return out;
}
function scalar(p,k,shape,field){return p&&p[k]&&p[k][shape]?p[k][shape][field||'value']:undefined;}
function parseJson(p,key,limit){var raw=scalar(p,key,'longText','text');if(typeof raw!=='string'||wire.utf8(raw).length>limit){return null;}try{return JSON.parse(raw);}catch(ignored){return null;}}
function sourceCard(instance,provider){
  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==4){return null;}
  if(!wire.integer(scalar(p,'revision','numericValue'),1,MAX)||!wire.integer(scalar(p,'observed_at','timestamp'),1,MAX)||
      !wire.integer(scalar(p,'valid_until','timestamp'),1,MAX)||typeof scalar(p,'private','boolean')!=='boolean'||typeof scalar(p,'unconfirmed','boolean')!=='boolean'){return null;}
  if(p.icon!==undefined&&(!wire.object(p.icon)||!p.icon.image&&!p.icon.icon)||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
  var record=parseJson(p,'content',LIMITS.descriptor);if(!wire.object(record)||instance.instanceId!==record.id){return null;}
  delete record.entityRef;delete record.actions;delete record.openApp;delete record.artwork;
  if(record.icon&&typeof record.icon!=='string'){delete record.icon;}
  if(p.icon!==undefined){record.icon=p.icon.image||p.icon.icon;}
  if(p.artwork!==undefined){record.artwork=p.artwork.image||p.artwork.icon;}
  // Malformed optional capabilities are discarded independently of content.
  [['entity_ref','entityRef',LIMITS.entity],['actions','actions',LIMITS.actions],['open_app','openApp',LIMITS.openApp]].forEach(function(pair){
    if(p[pair[0]]!==undefined){var value=extension(parseJson(p,pair[0],pair[2]),pair[1]);if(value!==null){record[pair[1]]=value;}}
  });
  return sourceRecord({record:record,revision:scalar(p,'revision','numericValue'),observedAt:scalar(p,'observed_at','timestamp'),
    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
    displayName:scalar(p,'app_name','longText','text')},provider);
}
function header(envelope){
  if(!envelope||!Array.isArray(envelope.instances)||envelope.instances.length>17){return null;}
  var found=envelope.instances.filter(function(i){return i&&i.instanceId==='@snapshot';});
  if(found.length!==1){return null;}var p=found[0].properties;
  var h={mode:scalar(p,'publisher_mode','shortText','text'),incarnation:scalar(p,'publisher_incarnation','longText','text'),sequence:scalar(p,'snapshot_sequence','numericValue'),count:scalar(p,'activity_count','numericValue')};
  return scalar(p,'schema_version','numericValue')===4&&['fresh','snapshot'].indexOf(h.mode)>=0&&typeof h.incarnation==='string'&&text(h.incarnation,64)===h.incarnation&&wire.integer(h.sequence,1,MAX)&&wire.integer(h.count,0,16)&&h.count===envelope.instances.length-1?h:null;
}
function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
function imageProperty(image){return {image:{width:image.width,height:image.height,palette:base64(image.palette),pixels:base64(image.pixels)}};}
function toSourceInstance(input,request){
  var value=sourceRecord(input);if(!value){return null;}var r=value.record;
  var p={schema_version:{numericValue:{value:4}},revision:{numericValue:{value:value.revision}},observed_at:{timestamp:{value:value.observedAt}},valid_until:{timestamp:{value:value.validUntil}},
    private:{boolean:{value:value.private}},unconfirmed:{boolean:{value:value.unconfirmed}},content:{longText:{text:JSON.stringify(descriptor(r))}}};
  if(value.displayName){p.app_name={longText:{text:value.displayName}};}
  if(request&&request.iconPixelSize){if(r.icon&&typeof r.icon!=='string'){p.icon=imageProperty(r.icon);}if(r.artwork){p.artwork=imageProperty(r.artwork);}}
  [['entityRef','entity_ref'],['actions','actions'],['openApp','open_app']].forEach(function(pair){if(r[pair[0]]!==undefined){p[pair[1]]={longText:{text:JSON.stringify(r[pair[0]])}};}});
  return {instanceId:r.id,properties:p};
}
function provider(options,snapshot){
  options=options||{};
  if(!wire.uuid(options.pluginUuid)||!options.storage||typeof options.storage.getItem!=='function'||typeof options.storage.setItem!=='function'||typeof options[snapshot?'readSnapshot':'readCurrent']!=='function'){throw new Error('INVALID_PROVIDER');}
  var refresh=options.refreshSeconds===undefined?30:options.refreshSeconds,validity=options.validitySeconds===undefined?90:options.validitySeconds;
  if(!wire.integer(refresh,1,MAX)||!wire.integer(validity,refresh+1,MAX)){throw new Error('INVALID_VALIDITY');}
  var now=options.now||Date.now,key=options.metadataKey||META_KEY;
  function reserve(){
    var meta;
    try{meta=JSON.parse(options.storage.getItem(key));}catch(ignored){}
    if(!known(meta,['version','incarnation','sequence'])||meta.version!==1||typeof meta.incarnation!=='string'||text(meta.incarnation,64)!==meta.incarnation||!wire.integer(meta.sequence,0,MAX)){
      meta={version:1,incarnation:String(now())+'-'+String(Math.random()).slice(2),sequence:0};
    }
    if(meta.sequence===MAX){throw new Error('SEQUENCE_EXHAUSTED');}meta.sequence++;
    var encoded=JSON.stringify(meta);options.storage.setItem(key,encoded);if(options.storage.getItem(key)!==encoded){throw new Error('STORAGE_UNAVAILABLE');}
    return meta;
  }
  function source(request){
    return Promise.resolve().then(function(){
    var meta=reserve();
    return Promise.resolve(options[snapshot?'readSnapshot':'readCurrent'](request||{})).then(function(raw){
      var records=Array.isArray(raw)?raw:raw&&raw.records,time=now(),observed=Math.max(1,Math.floor(time/1000)),seen=Object.create(null),instances=[];
      if(!Array.isArray(records)||records.length>16){throw new Error('INVALID_SNAPSHOT');}
      records.forEach(function(input){
        var entry;
        if(snapshot){entry=typeof options.adapt==='function'?options.adapt(input):input;}
        else{entry={record:input,revision:meta.sequence,observedAt:observed,validUntil:Math.min(MAX,observed+validity),private:true,unconfirmed:false};}
        if(!entry){throw new Error('INVALID_SNAPSHOT');}
        var copy={};Object.keys(entry).forEach(function(k){copy[k]=entry[k];});copy.displayName=options.displayName||copy.displayName;
        if(copy.record&&copy.record.icon===undefined&&options.icon!==undefined){copy.record=helper({icon:options.icon},copy.record);}
        var validated=normalize(copy.record,copy.observedAt);
        if(!validated||seen[validated.id]){throw new Error('INVALID_SNAPSHOT');}seen[validated.id]=true;
        copy.record=validated;
        if(validated.visibleUntil!==undefined&&validated.visibleUntil<=observed){return;}
        var result=sourceRecord(copy,options.pluginUuid);if(!result){throw new Error('INVALID_SNAPSHOT');}
        if(result.record.type==='standard'&&(result.record.state==='completed'||result.record.state==='cancelled')&&!result.record.result){return;}
        if(result.validUntil>observed){var instance=toSourceInstance(result,request);if(!instance){throw new Error('INVALID_SNAPSHOT');}instances.push(instance);}
      });
      var count=instances.length;
      instances.unshift({instanceId:'@snapshot',properties:{schema_version:{numericValue:{value:4}},publisher_incarnation:{longText:{text:meta.incarnation}},publisher_mode:{shortText:{text:snapshot?'snapshot':'fresh'}},snapshot_sequence:{numericValue:{value:meta.sequence}},activity_count:{numericValue:{value:count}}}});
      var expiry=Math.min(MAX*1000,time+(snapshot?refresh:validity)*1000);
      if(raw&&!Array.isArray(raw)&&raw.validUntilMs!==undefined){if(!wire.integer(raw.validUntilMs,1,MAX*1000)){throw new Error('INVALID_SNAPSHOT');}expiry=Math.min(expiry,raw.validUntilMs);}
      return {validUntilMs:expiry,instances:instances};
    });
    });
  }
  function handleSource(request,respond){
    if(!request||request.category!=='activity'||request.item!=='summary'){if(respond&&respond.error){respond.error('INVALID_REQUEST','Unsupported source');}return Promise.resolve();}
    return Promise.resolve().then(function(){return source(request);}).then(function(result){respond.data(result);},function(error){respond.error(error&&/^(STORAGE_UNAVAILABLE|SEQUENCE_EXHAUSTED)$/.test(error.message)?error.message:'INVALID_DATA','Activity source unavailable');});
  }
  return {source:source,handleSource:handleSource,sourceDeclaration:{category:'activity',items:['summary'],properties:SOURCE_PROPERTIES,supportsMultiple:true,suggestedRefreshIntervalSec:refresh}};
}
function helper(base,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(base).forEach(function(k){result[k]=base[k];});return result;}
function timerSnapshot(raw){
  var original=wire.normalize(raw);if(!original||original.kind!=='timer'){return null;}
  var headline;
  if(original.state==='active'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',deadline:original.deadline};}
  else if(original.state==='paused'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',seconds:original.duration};}
  else{headline={type:'text',text:original.state==='completed'?'Finished':'Cancelled'};}
  var record={id:original.id,type:'standard',icon:'timer',headline:headline,state:original.state,result:raw.showTerminal===true,
    openApp:{watchAppUuid:'50e9ef12-a5ab-4369-a3b5-3447bfba5151'}};
  var name=text(original.footer,64);if(name){record.name=name;}
  var validUntil=original.validUntil;
  if(original.state==='paused'){validUntil=Math.min(validUntil,original.observedAt+300);}
  if(original.state==='active'&&original.deadline){validUntil=Math.min(validUntil,original.deadline+60);}
  return {record:record,revision:original.revision,observedAt:original.observedAt,validUntil:validUntil,private:original.private,unconfirmed:true};
}
function toView(input,provider){return require(8).fromSummary(input,provider);}
module.exports={VERSION:4,CATEGORY:'activity',ITEM:'summary',LIMITS:LIMITS,ICONS:ICONS,DIRECTIONS:DIRECTIONS,METADATA_KEY:META_KEY,
  SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),normalize:normalize,datum:datum,sourceRecord:sourceRecord,sourceCard:sourceCard,header:header,
  descriptor:descriptor,toSourceInstance:toSourceInstance,toView:toView,extension:extension,
  standard:function(id,options){return helper({id:id,type:'standard'},options);},media:function(id,options){return helper({id:id,type:'media'},options);},
  text:function(value,options){return helper({type:'text',text:value},options);},
  value:function(value,unit,options){var out={type:'value',value:value};if(unit!==undefined&&unit!==''){out.unit=unit;}return helper(out,options);},
  countdown:function(options){return helper({type:'clock',mode:'countdown'},options);},elapsed:function(options){return helper({type:'clock',mode:'elapsed'},options);},
  defineProvider:function(options){return provider(options,false);},defineSnapshotProvider:function(options){return provider(options,true);},adapters:{timerSnapshot:timerSnapshot}};

},
function(module,exports,require){
'use strict';

// ACT3 is the bounded two-role projection. It preserves ACT2's datum layout
// while adding explicit media, summary and semantic-symbol metadata.
var wire=require(3),view=require(4),summary=require(7),MAX=wire.MAX_EPOCH;
var PRESENTATIONS={text:1,media:2,clock:3,value:4,ranged:5};
var LIMITS={cards:2,packet:2672,pool:304,header:104};
function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
function clone(v){return JSON.parse(JSON.stringify(v));}
function put16(b,o,v){b[o]=v&255;b[o+1]=(v>>>8)&255;}
function put32(b,o,v){for(var i=0;i<4;i++){b[o+i]=Math.floor(v/Math.pow(256,i))&255;}}
function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
function token(value){
  var bytes=wire.utf8(value||''),a=2166136261,b=2246822519;
  bytes.forEach(function(x){a=(a^x)>>>0;a=(a*16777619)>>>0;b=(b^x)>>>0;b=(b*65599)>>>0;});
  var out=[];put32(out,0,a);put32(out,4,b);return out;
}
function poolFor(card){
  var bytes=[],known=Object.create(null);
  function add(value){value=value||'';if(own(known,value)){return known[value];}var data=wire.utf8(value),ref={offset:bytes.length,length:data.length};known[value]=ref;bytes=bytes.concat(data,[0]);return ref;}
  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)},qualifier:add(card.qualifier)};
  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
  return {bytes:bytes,refs:refs};
}
function normalize(input){
  var card=view.normalize(input,undefined,true);if(!card){return null;}
  card.main.label=wire.text(card.main.label,32);if(card.support){card.support.label=wire.text(card.support.label,32);}
  card.presentation=input.presentation===undefined?(card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text):input.presentation;
  card.identitySymbol=input.identitySymbol===undefined?0:input.identitySymbol;
  card.compactItem=input.compactItem===undefined?0:input.compactItem;
  card.directions=input.directions===undefined?[0,0]:input.directions;
  card.qualifier=typeof input.qualifier==='string'?wire.text(input.qualifier,304):'';
  card.visualToken=input.visualToken===undefined?[0,0,0,0,0,0,0,0]:input.visualToken;
  if(!wire.integer(card.presentation,1,5)||!wire.integer(card.identitySymbol,0,10)||!wire.integer(card.compactItem,0,1)||card.compactItem&&!card.support||
    !Array.isArray(card.directions)||card.directions.length!==2||!card.directions.every(function(x){return wire.integer(x,0,4);})||
    !Array.isArray(card.visualToken)||card.visualToken.length!==8||!card.visualToken.every(function(x){return wire.integer(x,0,255);})){return null;}
  if(card.presentation===PRESENTATIONS.media&&(card.main.type!=='text'||card.support&&card.support.type!=='text'||card.compactItem||card.meter)){return null;}
  if(card.presentation===PRESENTATIONS.text&&card.main.type!=='text'||card.presentation===PRESENTATIONS.clock&&card.main.type!=='clock'||card.presentation===PRESENTATIONS.value&&card.main.type!=='value'||card.presentation===PRESENTATIONS.ranged&&(!card.meter||card.main.type!=='value'||card.meter.source!=='main')){return null;}
  if(card.directions[0]&&card.main.type!=='value'||card.directions[1]&&(!card.support||card.support.type!=='value')||card.presentation!==PRESENTATIONS.media&&card.visualToken.some(function(x){return x!==0;})){return null;}
  ['providerName','selectionKey','name','openApp','playback','sourceFormat','entityRef','actions','mediaItemId'].forEach(function(k){if(input[k]!==undefined){card[k]=clone(input[k]);}});
  // Keep shrinking monotonic even when strings share a pool reference.
  // Splitting a deduplicated string can increase storage, so optional aliases
  // are omitted rather than leaving ellipsis-only context behind.
  var fields=[['qualifier'],['caption'],['main','label'],['support','label']];
  if(card.support&&card.support.type==='text'){fields.push(['support','text']);}
  if(card.main.type==='text'){fields.push(['main','text']);}
  for(var f=0;poolFor(card).bytes.length>304&&f<fields.length;f++){
    var field=fields[f],owner=field.length===1?card:card[field[0]],key=field[field.length-1];if(!owner||!owner[key]){continue;}
    var requiredText=key==='text'&&(field[0]==='main'||card.compactItem===1||card.presentation===PRESENTATIONS.media);
    var before=poolFor(card).bytes.length,original=owner[key],size=wire.utf8(original).length;
    var limit=Math.max(requiredText?8:0,size-(before-304));
    owner[key]=limit<4?'':wire.text(original,limit);
    if(poolFor(card).bytes.length>=before){owner[key]=requiredText?wire.text(original,8):'';}
    if(field[0]==='support'&&key==='text'&&!owner.text){card.support=null;card.directions[1]=0;if(card.meter&&card.meter.source==='support'){card.meter=null;}}
  }
  if(poolFor(card).bytes.length>304||!card.main.text&&card.main.type!=='clock'||card.compactItem===1&&(!card.support||!card.support.text&&card.support.type!=='clock')){return null;}
  return card;
}
function compiledDatum(d,source){
  var out={type:d.type,label:d.label||'',observedAt:source.observedAt,validUntil:source.validUntil,retain:!source.private,estimated:false};
  if(d.type==='text'){out.text=d.text;}
  else if(d.type==='value'){out.text=numericText(d.value,d.unit||'');if(typeof d.value==='number'){out.value=d.value;out.unit=d.unit||'';}}
  else{out.mode=d.mode==='countdown'?'deadline':'elapsed';out.running=d.deadline!==undefined||d.since!==undefined;out.anchorAt=out.running?(d.since===undefined?source.observedAt:d.since):0;out.baseSeconds=d.deadline===undefined?d.seconds||0:Math.max(0,d.deadline-source.observedAt);}
  return out;
}
function textPart(d){return d&&d.type==='text'?(d.label?d.label+': ':'')+d.text:'';}
function unique(parts){var seen=Object.create(null);return parts.filter(function(x){if(!x||seen[x]){return false;}seen[x]=true;return true;}).join(' · ');}
function fromSummary(input,provider){
  var source=summary.sourceRecord(input,provider);if(!source){return null;}
  var r=source.record,media=r.type==='media',selected=r.summary==='detail'?1:0;
  var card={provider:source.provider,id:r.id,kind:media?'music':typeof r.icon==='string'?r.icon:'activity',revision:source.revision,state:media?'active':r.state,
    observedAt:source.observedAt,validUntil:source.validUntil,private:source.private,unconfirmed:source.unconfirmed,showTerminal:!media&&r.result,
    caption:media?r.artist||'':r.name||source.displayName||'',main:media?compiledDatum({type:'text',text:r.title},source):compiledDatum(r.headline,source),
    support:media?(r.artist?compiledDatum({type:'text',text:r.artist},source):null):(r.detail?compiledDatum(r.detail,source):null),
    image:media?r.artwork||typeof r.icon==='object'&&r.icon:typeof r.icon==='object'?r.icon:undefined,
    compactItem:media?0:selected,identitySymbol:summary.ICONS.indexOf(typeof r.icon==='string'?r.icon:media?'media':'activity'),
    directions:media?[0,0]:[summary.DIRECTIONS.indexOf(r.headline.symbol)+1,summary.DIRECTIONS.indexOf(r.detail&&r.detail.symbol)+1],
    presentation:media?PRESENTATIONS.media:r.headline.type==='clock'?PRESENTATIONS.clock:r.headline.type==='value'?(r.headline.range?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text,
    visualToken:media?token(r.itemId===undefined?r.title:r.itemId):[0,0,0,0,0,0,0,0],
    qualifier:media?unique([r.name,r.artist].filter(function(part){return part!==r.title;})):unique([textPart(selected?r.headline:r.detail),r.name].filter(function(part){var d=selected?r.detail:r.headline;return part!==d.label&&part!==textPart(d);})),sourceFormat:4,playback:r.playback,mediaItemId:r.itemId};
  if(!card.image){delete card.image;}
  if(r.headline&&r.headline.range){card.meter={kind:'progress',source:'main',min:r.headline.range.min,max:r.headline.range.max};}
  if(r.openApp){card.openApp=r.openApp;}if(r.actions){card.actions=r.actions;}if(r.entityRef){card.entityRef=r.entityRef;}
  if(source.displayName){card.providerName=source.displayName;}if(r.name){card.name=r.name;}
  return normalize(card);
}
function fromLegacy(input){
  var card=input&&input.main?clone(input):view.fromLegacy(input);if(!card){return null;}
  var media=card.kind==='music';
  card.presentation=media?PRESENTATIONS.media:card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter&&card.meter.source==='main'?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text;
  var kind=card.kind==='music'?'media':card.kind==='notification'||card.kind==='notifications'?'message':card.kind;
  card.identitySymbol=Math.max(0,summary.ICONS.indexOf(kind));card.compactItem=0;card.directions=[0,0];card.qualifier='';
  if(media){
    if(card.caption&&card.caption.indexOf('__dynamic_media__')===0){card.caption=card.caption.slice('__dynamic_media__'.length);}
    card.visualToken=token(card.main.text);card.qualifier=card.support?card.support.text:'';card.caption=card.support?card.support.text:'';
  }
  [card.main,card.support].forEach(function(d){if(d&&['Track','Artist','Text','Value','Left','Activity','Music',card.caption,card.providerName].indexOf(d.label)>=0){d.label='';}});
  if(!media){card.qualifier=unique([card.support&&card.support.type==='text'?card.support.text:'',card.caption]);}
  return normalize(card);
}
function writeDatum(header,offset,item,refs){
  if(!item){return;}header[offset]=view.TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
}
function encode(cards,options){
  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
  var out=[65,67,84,51,3,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
  cards.forEach(function(raw){
    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
    var pool=poolFor(card),id=wire.utf8(card.id),h=[];for(var i=0;i<104;i++){h.push(0);}
    h[2]=wire.STATES[card.state];h[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
    put32(h,4,card.revision);put32(h,8,card.observedAt);put32(h,12,card.validUntil);h[16]=id.length;h[17]=card.image?card.image.width:0;h[18]=card.image?card.image.height:0;h[19]=card.meter?view.METERS[card.meter.kind]:0;
    put16(h,20,card.image?card.image.pixels.length:0);put16(h,22,pool.bytes.length);put16(h,24,pool.refs.caption.offset);put16(h,26,pool.refs.caption.length);
    put16(h,28,card.meter?Math.round(card.meter.fraction*65535):0);h[30]=card.meter&&card.meter.source==='support'?1:0;
    writeDatum(h,32,card.main,pool.refs.main);writeDatum(h,60,card.support,pool.refs.support);
    h[88]=card.presentation;h[89]=card.identitySymbol;h[90]=card.compactItem;h[91]=card.directions[0]|card.directions[1]<<3;
    put16(h,92,pool.refs.qualifier.offset);put16(h,94,pool.refs.qualifier.length);for(i=0;i<8;i++){h[96+i]=card.visualToken[i];}
    var record=h.concat(wire.utf8(card.provider),id,pool.bytes);if(card.image){record=record.concat(card.image.palette,card.image.pixels);}put16(record,0,record.length);out=out.concat(record);
  });
  if(out.length>2672){throw new Error('SNAPSHOT_TOO_LARGE');}put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
}
function formatDatum(d,now){
  if(d.type==='text'){return textPart(d);}
  if(d.type==='value'){return numericText(d.value,d.unit||'');}
  return wire.formatClock(d.mode==='countdown'?(d.deadline===undefined?d.seconds:Math.max(0,d.deadline-now)):Math.min(MAX,(d.seconds||0)+(d.since===undefined?0:Math.max(0,now-d.since))));
}
function compactText(record,now){
  var r=summary.normalize(record,now);if(!r){return null;}
  if(r.type==='media'){return unique([r.title,r.name,r.artist]);}
  var selected=r.summary==='detail'?r.detail:r.headline,other=r.summary==='detail'?r.headline:r.detail;
  return unique([formatDatum(selected,now),selected.type==='text'?'':selected.label,textPart(other),r.name]);
}
module.exports={VERSION:3,PRESENTATIONS:PRESENTATIONS,LIMITS:LIMITS,normalize:normalize,encode:encode,fromSummary:fromSummary,fromLegacy:fromLegacy,poolFor:poolFor,compactText:compactText,visualToken:token,numericText:numericText};

},
function(module,exports,require){
'use strict';

var KEY = 'timer-appearance-settings-v1';
function defaults() { return {version: 1, theme: 'light'}; }
function normalize(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 1 ||
      Object.keys(value).some(function(key) { return ['version', 'theme'].indexOf(key) === -1; }) ||
      ['light', 'dark'].indexOf(value.theme) === -1) return null;
  return {version: 1, theme: value.theme};
}
function load(storage) {
  try {
    var encoded=storage.getItem(KEY);
    return encoded===null||encoded===undefined ? defaults() : normalize(JSON.parse(encoded));
  } catch (error) { return null; }
}
function save(storage,value) {
  var settings=normalize(value);
  if(!settings)return false;
  try {
    var encoded=JSON.stringify(settings);
    storage.setItem(KEY,encoded);
    return storage.getItem(KEY)===encoded;
  } catch(error) {return false;}
}
function handle(storage,message,respond,saved) {
  try {
    if(typeof message==='string')message=JSON.parse(message);
    if(!message||message.type==='getSettings'||message.type==='load_settings') {
      var encoded=storage.getItem(KEY),current;
      if(encoded===null||encoded===undefined)current=defaults();
      else { try { current=normalize(JSON.parse(encoded)); } catch(error) { current=null; } }
      respond({ok:true,settings:current||defaults(),needsRepair:!current});
    } else if(message.type==='saveSettings'||message.type==='save_settings') {
      var chosen=normalize(message.settings);
      if(!chosen){respond({ok:false,error:'invalid_settings'});return;}
      if(!save(storage,chosen)){respond({ok:false,error:'save_unconfirmed'});return;}
      if(saved)saved(chosen);
      respond({ok:true,settings:chosen});
    } else respond({ok:false,error:'unknown_request'});
  } catch(error){respond({ok:false,error:'save_unconfirmed'});}
}
function message(value) {
  var settings=normalize(value);
  return settings?{TIMER_APPEARANCE:settings.theme==='dark'?1:0,TIMER_APPEARANCE_VERSION:1}:null;
}
module.exports={key:KEY,defaults:defaults,normalize:normalize,load:load,save:save,handle:handle,message:message};

}
]);
