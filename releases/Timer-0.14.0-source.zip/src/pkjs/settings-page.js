'use strict';

function behavior() {
  'use strict';
  var cs=typeof navigator!=='undefined'&&/^cs(?:-|$)/i.test(navigator.language||'');
  var words={
    intro:['Appearance for Timer on your watch.','Vzhled aplikace Timer na hodinkách.'],appearance:['Appearance','Vzhled'],theme:['Watch appearance','Vzhled hodinek'],light:['Light','Světlý'],dark:['Dark','Tmavý'],
    hint:['The watch appearance is independent of this phone page.','Vzhled hodinek je nezávislý na vzhledu této stránky.'],help:['Setup & help','Nastavení a nápověda'],
    helpText:['Create, pause, reset and manage timers on the watch. These settings change appearance only.','Časovače vytváříte, pozastavujete, obnovujete a spravujete na hodinkách. Toto nastavení mění pouze vzhled.'],
    delivery:['Saved appearance applies when Timer is open and connected. Timer keeps its last confirmed appearance on startup.','Uložený vzhled se použije při otevření aplikace Timer a připojených hodinkách. Při spuštění Timer použije poslední potvrzený vzhled.'],
    save:['Save','Uložit'],discard:['Discard','Zahodit změny'],reload:['Reload saved','Načíst uložené'],retry:['Retry loading','Zkusit načíst znovu'],
    loading:['Loading settings…','Načítání nastavení…'],loadingChoice:['Loading saved choice…','Načítání uložené volby…'],notLoaded:['Not loaded','Nenačteno'],none:['No changes to save.','Žádné změny k uložení.'],dirty:['Unsaved changes','Neuložené změny'],saving:['Saving…','Ukládání…'],saved:['✓ Saved','✓ Uloženo'],
    uncertain:['Save not confirmed. Reload saved settings or try again.','Uložení není potvrzené. Načtěte uložené nastavení nebo to zkuste znovu.'],failed:['Couldn’t save. Try again.','Nepodařilo se uložit. Zkuste to znovu.'],loadFailed:['Could not load settings. Retry, or reopen this page from Pebble.','Nastavení se nepodařilo načíst. Zkuste to znovu nebo stránku znovu otevřete z aplikace Pebble.'],repair:['Saved settings could not be read. Review this choice before saving.','Uložené nastavení se nepodařilo přečíst. Před uložením zkontrolujte zvolený vzhled.'],reloaded:['Saved settings reloaded.','Uložené nastavení bylo znovu načteno.']
  };
  function t(key){return words[key][cs?1:0];}
  document.documentElement.lang=cs?'cs':'en';
  Array.prototype.forEach.call(document.querySelectorAll('[data-t]'),function(el){el.textContent=t(el.getAttribute('data-t'));});
  var field=document.getElementById('theme'),form=document.getElementById('settings');
  var save=document.getElementById('save'),discard=document.getElementById('discard'),retry=document.getElementById('retry'),status=document.getElementById('status'),actions=document.getElementById('actions');
  var loaded=false,repairing=false,uncertain=false,saved='',phase='loading',operation=0,timer=null,bridgeReady=false,pkjsReady=false,layoutPending=false,lastHeight='',lastFlow=null;
  function normalize(value){return value&&value.version===1&&Object.keys(value).length===2&&['light','dark'].indexOf(value.theme)!==-1?{version:1,theme:value.theme}:null;}
  function value(){return normalize({version:1,theme:field.value});}
  function edited(){return loaded&&JSON.stringify(value())!==saved;}
  function dirty(){return loaded&&(repairing||uncertain||edited());}
  function layout(){
    if(layoutPending)return;layoutPending=true;
    (window.requestAnimationFrame||function(fn){return setTimeout(fn,0);})(function(){
      layoutPending=false;
      var viewport=window.visualViewport&&window.visualViewport.height||window.innerHeight,height=actions.getBoundingClientRect().height;
      var flow=viewport<560||height>viewport*.28;
      if(flow!==lastFlow){actions.setAttribute('data-flow',String(flow));lastFlow=flow;}
      var size=flow?'0px':Math.ceil(height)+'px';
      if(size!==lastHeight){document.documentElement.style.setProperty('--actions-height',size);lastHeight=size;}
    });
  }
  function say(key,error){status.textContent=t(key);status.className=error?'status error':'status';layout();}
  function controls(){field.options[0].textContent=t(phase==='load-error'?'notLoaded':'loadingChoice');field.disabled=!loaded||phase==='saving';save.disabled=!loaded||phase==='saving'||!dirty()||!value();save.textContent=t(phase==='saving'?'saving':'save');discard.hidden=!loaded;discard.disabled=phase==='saving'||!uncertain&&!edited();discard.textContent=t(uncertain?'reload':'discard');retry.hidden=phase!=='load-error';}
  function apply(chosen,repair){field.value=chosen.theme;loaded=true;repairing=!!repair;uncertain=false;saved=JSON.stringify(chosen);phase='ready';controls();say(repairing?'repair':'none',repairing);}
  function stop(){if(timer!==null)clearTimeout(timer);timer=null;}
  function request(payload,complete,failed,target){
    var current=++operation;stop();
    timer=setTimeout(function(){if(current===operation){operation++;timer=null;failed();}},6000);
    function finish(callback,response){if(current!==operation)return;operation++;stop();callback(response);}
    try{
      var pending=Pebble.sendMessage(target||'plugin',payload);
      if(!pending||typeof pending.then!=='function'){finish(failed);return;}
      pending.then(function(response){finish(complete,response);},function(){finish(failed);});
    }catch(error){finish(failed);}
  }
  function loadFailed(){loaded=false;phase='load-error';controls();say('loadFailed',true);}
  function load(){
    var readback=uncertain;loaded=false;phase='loading';field.value='';controls();say('loading');
    if(!bridgeReady){stop();timer=setTimeout(loadFailed,6000);return;}
    request({type:'getSettings'},function(response){var chosen=response&&response.ok===true&&normalize(response.settings);if(!chosen){loadFailed();return;}apply(chosen,response.needsRepair);if(readback&&!repairing)say('reloaded');},loadFailed);
  }
  field.onchange=function(){controls();say(uncertain?'uncertain':edited()?'dirty':repairing?'repair':'none',uncertain||repairing);};
  retry.onclick=load;
  discard.onclick=function(){if(loaded&&uncertain)load();else if(loaded)apply(JSON.parse(saved),repairing);};
  function saveFailed(){uncertain=true;phase='ready';controls();say('uncertain',true);}
  function settingsTarget(complete,failed){
    if(typeof Pebble.targets!=='function'){complete(pkjsReady?'pkjs':'plugin');return;}
    var settled=false,timeout=setTimeout(function(){finish(failed);},6000);
    function finish(callback,target){if(settled)return;settled=true;clearTimeout(timeout);callback(target);}
    try{Promise.resolve(Pebble.targets()).then(function(targets){if(!Array.isArray(targets)){finish(failed);return;}finish(complete,targets.some(function(target){return target&&target.id==='pkjs';})?'pkjs':'plugin');},function(){finish(failed);});}catch(error){finish(failed);}
  }
  form.onsubmit=function(event){
    if(event)event.preventDefault();if(save.disabled)return;
    var selected=value();if(!selected)return;
    phase='saving';controls();say('saving');var attempts=0;
    function confirmed(chosen){apply(chosen,false);say('saved');}
    function write(target){
      if(++attempts>3){saveFailed();return;}
      request({type:'saveSettings',settings:selected},function(response){
        var accepted=response&&response.ok===true&&normalize(response.settings);
        if(!accepted||JSON.stringify(accepted)!==JSON.stringify(selected)){
          if(response&&response.error==='invalid_settings'){phase='ready';controls();say('failed',true);}else saveFailed();return;
        }
        // Android can restore a separate PKJS storage snapshot. The live writer
        // must own the final save before its teardown replaces native storage.
        if(target==='plugin')settingsTarget(function(current){if(current==='pkjs')write(current);else confirmed(accepted);},saveFailed);
        else confirmed(accepted);
      },function(){if(target!=='pkjs'){saveFailed();return;}settingsTarget(function(current){if(current==='plugin')write(current);else saveFailed();},saveFailed);},target);
    }
    settingsTarget(write,saveFailed);
  };
  save.onclick=function(event){if(event)event.preventDefault();form.onsubmit();};
  window.addEventListener('resize',layout);if(window.visualViewport)window.visualViewport.addEventListener('resize',layout);if(typeof ResizeObserver!=='undefined')new ResizeObserver(layout).observe(actions);
  if(typeof Pebble!=='undefined'&&typeof Pebble.addEventListener==='function')Pebble.addEventListener('ready',function(event){if(event&&event.target==='pkjs'){pkjsReady=true;return;}if(event&&event.target&&event.target!=='plugin')return;if(bridgeReady)return;bridgeReady=true;load();});
  load();
}
function render(){return [
  '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Timer</title><style>',
  ':root{color-scheme:light;--page:#f4f5f7;--card:#fff;--ink:#15181c;--muted:#5d6571;--line:#d9dee6;--accent:#145ca3;--accent-ink:#fff;--field:#f4f5f7;--error:#a1231d}',
  '@media(prefers-color-scheme:dark){:root{color-scheme:dark;--page:#11151b;--card:#1d232d;--ink:#f3f5f7;--muted:#b5bfcc;--line:#465165;--accent:#77bbff;--accent-ink:#10151b;--field:#11151b;--error:#ffb4ab}}',
  '*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}html{scroll-padding-bottom:calc(var(--actions-height,144px) + 16px)}main{max-width:512px;margin:auto;padding:24px 16px calc(var(--actions-height,144px) + 24px)}header{margin-bottom:24px}header:after{content:"";display:block;width:48px;height:4px;border-radius:2px;background:var(--accent)}h1{margin:0;font-size:28px;line-height:1.2;letter-spacing:-.6px}header>p{margin:12px 0 16px;color:var(--muted)}h2{margin:0 0 16px;font-size:20px;line-height:1.3;font-weight:700}p{margin:0 0 16px}',
  '.card{margin:0 0 24px;padding:16px;background:var(--card);border:1px solid var(--line);border-radius:12px}label{display:block;margin:16px 0 8px;font-weight:650}select,button{font:inherit;min-height:44px;border-radius:8px;transition:border-color 144ms ease,background-color 144ms ease,transform 144ms ease}select{width:100%;padding:11px 10px;border:1px solid var(--line);background:var(--field);color:var(--ink)}button{padding:10px 12px;border:1px solid var(--line);background:var(--field);color:var(--ink);font-weight:650;cursor:pointer}button:active:not(:disabled){transform:translateY(1px)}button:disabled{opacity:.45;cursor:default}select:disabled{opacity:.6}button:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:3px}.hint{font-size:14px;color:var(--muted);margin:8px 0 0}',
  'details>summary{min-height:44px;display:list-item;align-content:center;cursor:pointer;font-weight:650;color:var(--ink)}details[open]>summary{margin-bottom:16px}details>p{font-size:14px;color:var(--muted);margin-top:0}details[open]>p{animation:disclose 160ms ease-out}details>p:last-child{margin-bottom:0}@keyframes disclose{from{opacity:.6;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){select,button{transition:none}details[open]>p{animation:none}button:active:not(:disabled){transform:none}}footer{position:fixed;bottom:0;left:0;right:0;padding:16px 16px max(16px,env(safe-area-inset-bottom));background:var(--page);border-top:1px solid var(--line)}footer[data-flow=true]{position:static}.footer-inner{max-width:480px;margin:auto}.status{font-size:14px;color:var(--muted);margin:0 0 12px;min-height:20px;text-align:left}.status.error{color:var(--error)}.actions{display:flex;gap:8px}.actions button{flex:1;min-width:0;overflow-wrap:anywhere}footer[data-flow=true] .actions{flex-direction:column}#save{min-height:48px;background:var(--accent);border-color:var(--accent);color:var(--accent-ink)}[hidden]{display:none!important}@media(max-width:340px){.actions button{font-size:15px}}',
  '</style></head><body><main><header><h1>Timer</h1><p data-t="intro">Appearance for Timer on your watch.</p></header><form id="settings"><section class="card"><h2 data-t="appearance">Appearance</h2><label for="theme" data-t="theme">Watch appearance</label><select id="theme" aria-describedby="theme-help" disabled><option value="" disabled hidden selected data-t="loadingChoice">Loading saved choice…</option><option value="light" data-t="light">Light</option><option value="dark" data-t="dark">Dark</option></select><p id="theme-help" class="hint" data-t="hint">The watch appearance is independent of this phone page.</p></section></form><details class="card"><summary data-t="help">Setup &amp; help</summary><p data-t="helpText">Create, pause, reset and manage timers on the watch. These settings change appearance only.</p><p data-t="delivery">Saved appearance applies when Timer is open and connected. Timer keeps its last confirmed appearance on startup.</p></details></main><footer id="actions"><div class="footer-inner"><p id="status" class="status" role="status" aria-live="polite" data-t="loading">Loading settings…</p><div class="actions"><button id="retry" type="button" hidden data-t="retry">Retry loading</button><button id="discard" type="button" disabled data-t="discard">Discard</button><button id="save" type="submit" form="settings" disabled data-t="save">Save</button></div></div></footer><script>(',behavior.toString(),')();</script></body></html>'
].join('\n');}
module.exports={config:render};
