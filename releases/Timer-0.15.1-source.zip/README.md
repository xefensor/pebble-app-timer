# Timer

A native timer for stock PebbleOS with eight saved timers, watch-owned alarms and optional
activity sharing.

## Download

[Version 0.14.5](https://github.com/xefensor/pebble-app-timer/releases/tag/v0.14.5) is a development prerelease.

[PBW](https://github.com/xefensor/pebble-app-timer/releases/download/v0.14.5/Timer-0.14.5.pbw),
[source](https://github.com/xefensor/pebble-app-timer/releases/download/v0.14.5/Timer-0.14.5-source.zip),
[debug files](https://github.com/xefensor/pebble-app-timer/releases/download/v0.14.5/Timer-0.14.5-debug.zip), and
[checksums](https://github.com/xefensor/pebble-app-timer/releases/download/v0.14.5/SHA256SUMS.txt).

Install the PBW through the Pebble phone app. No separate library installation is needed.

Create a timer with the watch buttons. Select pauses/resumes or starts a Ready timer; More
options offers Reset and safe deletion. Native Wakeup owns accepted alarms while the app is
closed. Optional sharing requires phone plugin support. The phone settings page chooses
Light/Dark appearance and confirms Save without closing.

[Usage and controls](docs/USAGE.md) · [Current UI](docs/UI.md).

## Compatibility

The release candidate targets **Pebble Time 2 / Emery** and **Round 2 / Gabbro**, using **Pebble SDK 4.44**. Duo is deferred. Portable and
emulator evidence is versioned; physical phone/watch checks retain their documented gaps.
Existing screenshots keep their original version and provenance.

## Setup and use

Install the PBW through the Pebble phone app. Create, start, pause and manage timers on the watch; native deadlines and alarms remain usable offline. The phone settings change this app’s appearance. See [current UI and controls](docs/UI.md).

The version notes below describe the published download. Development candidates
remain separate; use [CONTRIBUTING](CONTRIBUTING.md) for local builds.

## Version 0.14.5

- Adopt shared XOCE headers, readable type roles, full-height action rails, canonical icons and stock Pebble action-bar feedback.
- Keep one timer anchored at the first-row position. Match native duration-editor movement while retaining rigid 120 ms menu selection.
- Preserve a valid later alarm when scheduling its replacement fails. Keep timer ownership, eight slots, persistence and explicit Reset/Start behavior.
- Bundle UI 0.1.1 and the confirmed stay-open appearance settings page.

## Version 0.15.1 — stable release preparation

Add Time 2 and Round 2 SDK 4.44 builds, responsive timer rows and editor geometry. Preserve native alarms and saved timers.

Xef accepted the reviewed implementation for stable release preparation on 2026-11-13. Actual test coverage remains recorded separately; no physical-device result is implied. Publication is a separate step.

## Development

Use Node 22, Python 3.12 and a C compiler. SDK builds additionally need Pebble SDK 4.44 on
PATH.

```sh
npm ci --ignore-scripts
npm test
npm run build
npm run check:artifact
```

[Contributor guide](CONTRIBUTING.md) · [Release preparation](docs/RELEASING.md) · [History index](docs/history/index.md).
Development outputs belong in ignored `build/`; published archives stay frozen.

The development candidate now proves native list → details → Back with
launch-time Pebble Text Size, the matching built-in Pebble type roles, measured
row density and restored timer selection.
The existing header and full-height rail remain. This is a local checkpoint,
with [scope and verification commands](docs/UI.md#development-checkpoint-list--details--back);
the published 0.14.5 download above remains unchanged.

## Licence

[PolyForm Noncommercial 1.0.0](LICENSE). Preserve bundled third-party notices and attribution.

The development checkout supports English, Czech, Slovak, German, French, Spanish,
Italian, Portuguese, Dutch, Polish, Danish, Swedish, Norwegian, Finnish, Hungarian,
Romanian and Turkish on watch screens and phone settings. Watch text follows the
watch language; settings follow the phone language. Regional locale codes and
Norwegian nb/nn are accepted; unsupported languages use English. Provider text,
user labels and saved bindings keep their original values. Frozen release downloads
retain their original language coverage until a new release is published.
